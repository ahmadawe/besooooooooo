import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as signInAnonymously } from "../_libs/firebase__auth.mjs";
import "../_libs/firebase.mjs";
import { a as getFirebaseServices, i as createSubmission, n as CURRENT_SUBMISSION_KEY, o as isFirebaseConfigured, t as Button, u as watchSubmission } from "./contest-DOAZkSQL.mjs";
import { n as TriangleAlert, o as GraduationCap, r as TicketCheck } from "../_libs/lucide-react.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DfVXIA1M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Index() {
	const [participantNumber, setParticipantNumber] = (0, import_react.useState)("");
	const [couponReference, setCouponReference] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [waiting, setWaiting] = (0, import_react.useState)(false);
	const [rejected, setRejected] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const navigate = useNavigate();
	const submit = async (event) => {
		event.preventDefault();
		setLoading(true);
		setError("");
		let unsubscribe;
		try {
			const { auth } = getFirebaseServices();
			const credential = auth.currentUser?.isAnonymous ? { user: auth.currentUser } : await signInAnonymously(auth);
			const submission = {
				id: crypto.randomUUID(),
				ownerUid: credential.user.uid,
				participantNumber: participantNumber.trim(),
				couponReference: couponReference.trim(),
				couponCode: "",
				couponStatus: "not_submitted",
				status: "pending",
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			await createSubmission(submission);
			window.sessionStorage.setItem(CURRENT_SUBMISSION_KEY, submission.id);
			setLoading(false);
			setWaiting(true);
			unsubscribe = watchSubmission(submission.id, (current) => {
				if (current?.status === "accepted") {
					unsubscribe?.();
					setWaiting(false);
					navigate({ to: "/verify" });
				} else if (current?.status === "rejected") {
					unsubscribe?.();
					setWaiting(false);
					setRejected(true);
				}
			}, (watchError) => {
				setWaiting(false);
				setError(watchError.message);
			});
		} catch (submitError) {
			setError(submitError instanceof Error ? submitError.message : "تعذر إرسال الطلب التجريبي.");
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "bank-page demo-page",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "bank-header demo-header",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "demo-brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { "aria-hidden": "true" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مختبر المشاريع الجامعية" })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "login-content demo-content",
				"aria-label": "نموذج تجربة المسابقة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "demo-mark",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCheck, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "participation-heading",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCheck, { "aria-hidden": "true" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "نموذج تجربة المسابقة" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "demo-warning",
						role: "alert",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { "aria-hidden": "true" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "مشروع جامعي تجريبي ومخادع لأغراض الاختبار فقط" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ممنوع إدخال أو مشاركة أي بيانات حقيقية. استخدم قيماً وهمية فقط، مثل DEMO-001 وTEST-123. لا تُدخل كلمات مرور أو أرقام هواتف أو رموز تحقق." })] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "participation-intro",
						children: "هذا النموذج يوضّح تدفق مراجعة الطلبات باستخدام بيانات تجريبية."
					}),
					!isFirebaseConfigured() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "demo-error",
						role: "alert",
						children: "إعداد Firebase غير مكتمل. راجع ملف .env.local ثم أعد تشغيل الموقع."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "login-form",
						onSubmit: submit,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "participation-label",
								children: ["معرّف تجريبي للمشارك", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "bank-input",
									"aria-label": "معرّف تجريبي للمشارك",
									placeholder: "مثال: DEMO-001",
									value: participantNumber,
									onChange: (e) => setParticipantNumber(e.target.value),
									autoComplete: "off",
									required: true,
									maxLength: 40
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "participation-label",
								children: ["مرجع تجريبي للكوبون", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "bank-input",
									"aria-label": "مرجع تجريبي للكوبون",
									placeholder: "مثال: TEST-123",
									value: couponReference,
									onChange: (e) => setCouponReference(e.target.value),
									autoComplete: "off",
									required: true,
									maxLength: 40
								})]
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "demo-error",
								role: "alert",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "login-submit",
								type: "submit",
								variant: "bank",
								disabled: loading || !isFirebaseConfigured(),
								children: loading ? "جارٍ الإرسال..." : "إرسال طلب تجريبي للمراجعة"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "demo-label",
						children: "بيانات وهمية فقط · مشروع تعليمي غير تابع لأي مؤسسة أو جهة حقيقية"
					})
				]
			}),
			(loading || waiting) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "contest-overlay",
				role: "status",
				"aria-live": "polite",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "contest-loading",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "contest-spinner" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: waiting ? "الطلب التجريبي قيد المراجعة" : "يرجى الانتظار لحظات" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: waiting ? "ستتمكن من متابعة التجربة بعد مراجعة الطلب." : "جارٍ حفظ الطلب التجريبي في Firestore." })
					]
				})
			}),
			rejected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "contest-overlay",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "contest-loading",
					role: "alertdialog",
					"aria-modal": "true",
					"aria-labelledby": "rejected-title",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "rejected-title",
							children: "لم يُقبل الطلب التجريبي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "يمكنك استخدام قيم وهمية أخرى والمحاولة مجددًا." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "bank",
							onClick: () => {
								setRejected(false);
								setParticipantNumber("");
								setCouponReference("");
							},
							children: "حسنًا"
						})
					]
				})
			})
		]
	});
}
//#endregion
export { Index as component };
