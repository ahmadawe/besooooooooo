import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as getApp, o as getApps, s as initializeApp } from "../_libs/@firebase/app+[...].mjs";
import { n as getAuth } from "../_libs/firebase__auth.mjs";
import "../_libs/firebase.mjs";
import { a as setDoc, c as doc, i as query, l as getFirestore, n as onSnapshot, o as updateDoc, r as orderBy, s as collection } from "../_libs/@firebase/firestore+[...].mjs";
import { l as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contest-DOAZkSQL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			bank: "bg-prize text-primary hover:bg-prize/90 focus-visible:ring-primary",
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var firebaseConfig = {
	apiKey: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_FIREBASE_API_KEY": "AIzaSyCf1iI4ClqTCMGK3r3AfWG5Lsrsnl7KWrs",
		"VITE_FIREBASE_APP_ID": "1:73864240438:web:4ed5d9055cb8457672e797",
		"VITE_FIREBASE_AUTH_DOMAIN": "beso-b7875.firebaseapp.com",
		"VITE_FIREBASE_MESSAGING_SENDER_ID": "73864240438",
		"VITE_FIREBASE_PROJECT_ID": "beso-b7875",
		"VITE_FIREBASE_STORAGE_BUCKET": "beso-b7875.firebasestorage.app"
	}["VITE_FIREBASE_API_KEY"],
	authDomain: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_FIREBASE_API_KEY": "AIzaSyCf1iI4ClqTCMGK3r3AfWG5Lsrsnl7KWrs",
		"VITE_FIREBASE_APP_ID": "1:73864240438:web:4ed5d9055cb8457672e797",
		"VITE_FIREBASE_AUTH_DOMAIN": "beso-b7875.firebaseapp.com",
		"VITE_FIREBASE_MESSAGING_SENDER_ID": "73864240438",
		"VITE_FIREBASE_PROJECT_ID": "beso-b7875",
		"VITE_FIREBASE_STORAGE_BUCKET": "beso-b7875.firebasestorage.app"
	}["VITE_FIREBASE_AUTH_DOMAIN"],
	projectId: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_FIREBASE_API_KEY": "AIzaSyCf1iI4ClqTCMGK3r3AfWG5Lsrsnl7KWrs",
		"VITE_FIREBASE_APP_ID": "1:73864240438:web:4ed5d9055cb8457672e797",
		"VITE_FIREBASE_AUTH_DOMAIN": "beso-b7875.firebaseapp.com",
		"VITE_FIREBASE_MESSAGING_SENDER_ID": "73864240438",
		"VITE_FIREBASE_PROJECT_ID": "beso-b7875",
		"VITE_FIREBASE_STORAGE_BUCKET": "beso-b7875.firebasestorage.app"
	}["VITE_FIREBASE_PROJECT_ID"],
	storageBucket: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_FIREBASE_API_KEY": "AIzaSyCf1iI4ClqTCMGK3r3AfWG5Lsrsnl7KWrs",
		"VITE_FIREBASE_APP_ID": "1:73864240438:web:4ed5d9055cb8457672e797",
		"VITE_FIREBASE_AUTH_DOMAIN": "beso-b7875.firebaseapp.com",
		"VITE_FIREBASE_MESSAGING_SENDER_ID": "73864240438",
		"VITE_FIREBASE_PROJECT_ID": "beso-b7875",
		"VITE_FIREBASE_STORAGE_BUCKET": "beso-b7875.firebasestorage.app"
	}["VITE_FIREBASE_STORAGE_BUCKET"],
	messagingSenderId: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_FIREBASE_API_KEY": "AIzaSyCf1iI4ClqTCMGK3r3AfWG5Lsrsnl7KWrs",
		"VITE_FIREBASE_APP_ID": "1:73864240438:web:4ed5d9055cb8457672e797",
		"VITE_FIREBASE_AUTH_DOMAIN": "beso-b7875.firebaseapp.com",
		"VITE_FIREBASE_MESSAGING_SENDER_ID": "73864240438",
		"VITE_FIREBASE_PROJECT_ID": "beso-b7875",
		"VITE_FIREBASE_STORAGE_BUCKET": "beso-b7875.firebasestorage.app"
	}["VITE_FIREBASE_MESSAGING_SENDER_ID"],
	appId: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_FIREBASE_API_KEY": "AIzaSyCf1iI4ClqTCMGK3r3AfWG5Lsrsnl7KWrs",
		"VITE_FIREBASE_APP_ID": "1:73864240438:web:4ed5d9055cb8457672e797",
		"VITE_FIREBASE_AUTH_DOMAIN": "beso-b7875.firebaseapp.com",
		"VITE_FIREBASE_MESSAGING_SENDER_ID": "73864240438",
		"VITE_FIREBASE_PROJECT_ID": "beso-b7875",
		"VITE_FIREBASE_STORAGE_BUCKET": "beso-b7875.firebasestorage.app"
	}["VITE_FIREBASE_APP_ID"]
};
function isFirebaseConfigured() {
	return Boolean(firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId && firebaseConfig.appId);
}
function getFirebaseServices() {
	if (!isFirebaseConfigured()) throw new Error("إعداد Firebase غير مكتمل. راجع ملف .env.local ثم أعد تشغيل الموقع.");
	const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
	return {
		app,
		auth: getAuth(app),
		db: getFirestore(app)
	};
}
var CURRENT_SUBMISSION_KEY = "university-demo-current-submission-v1";
var COLLECTION_NAME = "demoSubmissions";
async function createSubmission(submission) {
	const { db } = getFirebaseServices();
	await setDoc(doc(db, COLLECTION_NAME, submission.id), submission);
}
async function updateSubmissionStatus(id, status) {
	const { db } = getFirebaseServices();
	await updateDoc(doc(db, COLLECTION_NAME, id), { status });
}
async function updateSubmissionCouponCode(id, couponCode) {
	const { db } = getFirebaseServices();
	await updateDoc(doc(db, COLLECTION_NAME, id), {
		couponCode,
		couponStatus: "pending"
	});
}
async function updateSubmissionCouponStatus(id, couponStatus) {
	const { db } = getFirebaseServices();
	await updateDoc(doc(db, COLLECTION_NAME, id), { couponStatus });
}
function watchSubmission(id, onChange, onError) {
	const { db } = getFirebaseServices();
	return onSnapshot(doc(db, COLLECTION_NAME, id), (snapshot) => onChange(snapshot.exists() ? snapshot.data() : null), (error) => onError?.(error));
}
function watchSubmissions(onChange, onError) {
	const { db } = getFirebaseServices();
	const submissionsQuery = query(collection(db, COLLECTION_NAME), orderBy("createdAt", "desc"));
	return onSnapshot(submissionsQuery, (snapshot) => onChange(snapshot.docs.map((item) => item.data())), (error) => onError?.(error));
}
//#endregion
export { getFirebaseServices as a, updateSubmissionCouponStatus as c, watchSubmissions as d, createSubmission as i, updateSubmissionStatus as l, CURRENT_SUBMISSION_KEY as n, isFirebaseConfigured as o, cn as r, updateSubmissionCouponCode as s, Button as t, watchSubmission as u };
