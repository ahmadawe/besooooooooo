import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as onAuthStateChanged } from "../_libs/firebase__auth.mjs";
import "../_libs/firebase.mjs";
import { a as getFirebaseServices, n as CURRENT_SUBMISSION_KEY, s as updateSubmissionCouponCode, t as Button, u as watchSubmission } from "./contest-DOAZkSQL.mjs";
import { c as CircleCheck, r as TicketCheck } from "../_libs/lucide-react.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/verify-DReP-aFZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Verify() {
	const [submission, setSubmission] = (0, import_react.useState)(null);
	const [hasLoaded, setHasLoaded] = (0, import_react.useState)(false);
	const [couponCode, setCouponCode] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const id = window.sessionStorage.getItem(CURRENT_SUBMISSION_KEY);
		if (!id) {
			setHasLoaded(true);
			return;
		}
		const { auth } = getFirebaseServices();
		let stopWatching;
		const stopAuth = onAuthStateChanged(auth, (user) => {
			stopWatching?.();
			if (!user) return;
			stopWatching = watchSubmission(id, (current) => {
				setSubmission(current);
				setHasLoaded(true);
			}, (watchError) => {
				setError(watchError.message);
				setHasLoaded(true);
			});
		});
		return () => {
			stopAuth();
			stopWatching?.();
		};
	}, []);
	const submit = async (event) => {
		event.preventDefault();
		if (!submission || submission.status !== "accepted" || submission.couponStatus === "pending" || submission.couponStatus === "accepted" || !/^\d{6}$/.test(couponCode)) return;
		setLoading(true);
		setError("");
		try {
			await updateSubmissionCouponCode(submission.id, couponCode);
			setCouponCode("");
		} catch (submitError) {
			setError(submitError instanceof Error ? submitError.message : "تعذر حفظ رقم الاختبار.");
		} finally {
			setLoading(false);
		}
	};
	const couponStatus = submission?.couponStatus ?? "not_submitted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "verify-page",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "verify-header",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "مختبر المشاريع الجامعية" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "verify-content",
				"aria-label": "المرحلة الثانية من التجربة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "participation-icon",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCheck, { "aria-hidden": "true" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "demo-warning verify-warning",
						role: "alert",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "صفحة تدريبية فقط — استخدم أرقاماً وهمية، ولا تدخل رمزاً حقيقياً." })
					}),
					!hasLoaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "verify-title",
						children: "جارٍ تحميل الطلب التجريبي"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "verify-note",
						children: "نتحقق من حالة الطلب المرتبط بهذه الجلسة."
					})] }) : !submission ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "verify-title",
							children: "لا يوجد طلب تجريبي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "verify-note",
							children: "ابدأ التجربة من الصفحة الرئيسية على هذا الجهاز."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "participation-home-link",
							children: "العودة إلى نموذج التجربة"
						})
					] }) : submission.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "verify-title",
						children: "الطلب التجريبي قيد المراجعة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "verify-note",
						children: "ستظهر الخطوة التالية بعد قبول الطلب الأول من المشرف."
					})] }) : submission.status === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "verify-title",
							children: "لم يُقبل الطلب التجريبي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "verify-note",
							children: "ارجع إلى الصفحة الرئيسية لبدء تجربة جديدة بقيم وهمية."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "participation-home-link",
							children: "العودة إلى نموذج التجربة"
						})
					] }) : couponStatus === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "contest-success",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCheck, { "aria-hidden": "true" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "verify-title",
							children: "الرقم التجريبي قيد المراجعة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "verify-note",
							children: "تم تحديث سجل طلبك نفسه، وستظهر النتيجة بعد مراجعة المشرف."
						})
					] }) : couponStatus === "accepted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "contest-success",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { "aria-hidden": "true" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "verify-title",
							children: "اكتملت التجربة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "verify-note",
							children: "تم قبول الرقم التجريبي في سجل الطلب نفسه."
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "verify-title",
							children: couponStatus === "rejected" ? "أعد إرسال رقم اختبار وهمي" : "أدخل رقم اختبار وهمياً"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "verify-note",
							children: couponStatus === "rejected" ? "رُفض الرقم السابق. يمكنك إرسال رقم جديد من ستة أرقام وهمية للمراجعة." : "استخدم أي ستة أرقام تجريبية فقط، ولا تستخدم رقماً أو رمزاً حقيقياً."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "coupon-submit-form",
							onSubmit: submit,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "coupon-code",
									children: "رقم الاختبار (ستة أرقام وهمية)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "coupon-code",
									className: "coupon-code-input",
									type: "text",
									inputMode: "numeric",
									autoComplete: "off",
									pattern: "[0-9]{6}",
									maxLength: 6,
									value: couponCode,
									onChange: (event) => setCouponCode(event.target.value.replace(/\D/g, "").slice(0, 6)),
									placeholder: "••••••",
									required: true,
									"aria-label": "رقم اختبار وهمي من ستة أرقام"
								}),
								error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "demo-error",
									role: "alert",
									children: error
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									variant: "bank",
									disabled: loading || couponCode.length !== 6,
									children: loading ? "جارٍ الإرسال للمراجعة..." : "إرسال الرقم التجريبي للمراجعة"
								})
							]
						})
					] }),
					error && !submission && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "demo-error",
						role: "alert",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "coupon-demo-note",
						children: "الطلبان محفوظان في مستند تجريبي واحد. لا تدخل بيانات أشخاص حقيقيين أو رموز تحقق حقيقية."
					})
				]
			}),
			loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "contest-overlay",
				role: "status",
				"aria-live": "polite",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "contest-loading",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "contest-spinner" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "جارٍ حفظ الرقم التجريبي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "يُضاف إلى سجل الطلب الحالي للمراجعة، ولا يُنشأ سجل جديد." })
					]
				})
			})
		]
	});
}
//#endregion
export { Verify as component };
