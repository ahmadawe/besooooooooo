//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C2cP7OOc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "P:/بيسو العجل/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/verify"
		],
		preloads: ["/assets/index-bkeuR2vK.js", "/assets/jsx-runtime-ByaQ0wya.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-bkeuR2vK.js"
		} }]
	},
	"/": {
		filePath: "P:/بيسو العجل/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BfZi431U.js",
			"/assets/contest-DoGZuD9d.js",
			"/assets/graduation-cap-BSDs680L.js"
		]
	},
	"/admin": {
		filePath: "P:/بيسو العجل/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-cHhXfEot.js",
			"/assets/contest-DoGZuD9d.js",
			"/assets/graduation-cap-BSDs680L.js"
		]
	},
	"/verify": {
		filePath: "P:/بيسو العجل/src/routes/verify.tsx",
		children: void 0,
		preloads: ["/assets/verify-Br6mY64H.js", "/assets/contest-DoGZuD9d.js"]
	}
} });
//#endregion
export { tsrStartManifest };
