import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as updatePassword, i as reauthenticateWithCredential, o as signInWithEmailAndPassword, r as onAuthStateChanged, s as signOut, t as EmailAuthProvider } from "../_libs/firebase__auth.mjs";
import "../_libs/firebase.mjs";
import { c as doc, t as getDoc } from "../_libs/@firebase/firestore+[...].mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as getFirebaseServices, c as updateSubmissionCouponStatus, d as watchSubmissions, l as updateSubmissionStatus, o as isFirebaseConfigured, r as cn, t as Button } from "./contest-DOAZkSQL.mjs";
import { a as KeyRound, i as LogOut, l as Check, o as GraduationCap, r as TicketCheck, s as Clock3, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BhW62GIT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var DASHBOARD_ADMIN_EMAIL = "dashboard-admin@beso-b7875.firebaseapp.com";
var FILTERS = [
	{
		key: "all",
		label: "كل الطلبات"
	},
	{
		key: "request_pending",
		label: "الطلب: قيد المراجعة"
	},
	{
		key: "request_accepted",
		label: "الطلب: مقبول"
	},
	{
		key: "request_rejected",
		label: "الطلب: مرفوض"
	},
	{
		key: "number_pending",
		label: "الرقم: قيد المراجعة"
	},
	{
		key: "number_accepted",
		label: "الرقم: مقبول"
	},
	{
		key: "number_rejected",
		label: "الرقم: مرفوض"
	}
];
function AdminPage() {
	const [user, setUser] = (0, import_react.useState)(null);
	const [isAdmin, setIsAdmin] = (0, import_react.useState)(false);
	const [authReady, setAuthReady] = (0, import_react.useState)(false);
	const [password, setPassword] = (0, import_react.useState)("");
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmNewPassword, setConfirmNewPassword] = (0, import_react.useState)("");
	const [passwordChangeOpen, setPasswordChangeOpen] = (0, import_react.useState)(false);
	const [passwordChanged, setPasswordChanged] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [submissions, setSubmissions] = (0, import_react.useState)([]);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [selectedSubmissionId, setSelectedSubmissionId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!isFirebaseConfigured()) {
			setAuthReady(true);
			return;
		}
		const { auth, db } = getFirebaseServices();
		return onAuthStateChanged(auth, async (currentUser) => {
			setUser(currentUser);
			setIsAdmin(false);
			if (currentUser && !currentUser.isAnonymous) try {
				const role = await getDoc(doc(db, "adminUsers", currentUser.uid));
				setIsAdmin(role.exists() && role.data()["enabled"] === true);
			} catch (roleError) {
				setError(roleError instanceof Error ? roleError.message : "تعذر التحقق من صلاحيات المشرف.");
			}
			setAuthReady(true);
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!isAdmin) {
			setSubmissions([]);
			return;
		}
		try {
			return watchSubmissions(setSubmissions, (watchError) => setError(watchError.message));
		} catch (watchError) {
			setError(watchError instanceof Error ? watchError.message : "تعذر تحميل الطلبات.");
			return;
		}
	}, [isAdmin]);
	const counts = (0, import_react.useMemo)(() => ({
		all: submissions.length,
		requestPending: submissions.filter((item) => item.status === "pending").length,
		requestAccepted: submissions.filter((item) => item.status === "accepted").length,
		requestRejected: submissions.filter((item) => item.status === "rejected").length,
		numberPending: submissions.filter((item) => item.couponStatus === "pending").length,
		numberAccepted: submissions.filter((item) => item.couponStatus === "accepted").length,
		numberRejected: submissions.filter((item) => item.couponStatus === "rejected").length
	}), [submissions]);
	const filteredSubmissions = (0, import_react.useMemo)(() => submissions.filter((item) => matchesFilter(item, filter)), [submissions, filter]);
	const selectedSubmission = submissions.find((item) => item.id === selectedSubmissionId) ?? null;
	const login = async (event) => {
		event.preventDefault();
		setLoading(true);
		setError("");
		try {
			const { auth } = getFirebaseServices();
			await signInWithEmailAndPassword(auth, DASHBOARD_ADMIN_EMAIL, password);
			setPassword("");
		} catch {
			setError("تعذر تسجيل الدخول. تحقق من كلمة مرور المشرف وصلاحية الإدارة في Firestore.");
		} finally {
			setLoading(false);
		}
	};
	const changeAdminPassword = async (event) => {
		event.preventDefault();
		setError("");
		setPasswordChanged(false);
		if (newPassword.length < 6) {
			setError("كلمة المرور الجديدة يجب أن تتكون من 6 أحرف على الأقل.");
			return;
		}
		if (newPassword !== confirmNewPassword) {
			setError("تأكيد كلمة المرور غير مطابق.");
			return;
		}
		const currentUser = getFirebaseServices().auth.currentUser;
		if (!currentUser) {
			setError("انتهت جلسة الدخول. سجّل الدخول مرة أخرى ثم حاول.");
			return;
		}
		setLoading(true);
		try {
			const credential = EmailAuthProvider.credential(DASHBOARD_ADMIN_EMAIL, currentPassword);
			await reauthenticateWithCredential(currentUser, credential);
			await updatePassword(currentUser, newPassword);
			setCurrentPassword("");
			setNewPassword("");
			setConfirmNewPassword("");
			setPasswordChanged(true);
		} catch {
			setError("تعذر تغيير كلمة المرور. تأكد من كلمة المرور الحالية وأن الجديدة تستوفي شروط Firebase.");
		} finally {
			setLoading(false);
		}
	};
	const updateRequestStatus = async (id, status) => {
		setError("");
		try {
			await updateSubmissionStatus(id, status);
		} catch (updateError) {
			setError(updateError instanceof Error ? updateError.message : "تعذر تحديث حالة الطلب.");
		}
	};
	const updateNumberStatus = async (id, status) => {
		setError("");
		try {
			await updateSubmissionCouponStatus(id, status);
		} catch (updateError) {
			setError(updateError instanceof Error ? updateError.message : "تعذر تحديث مراجعة الرقم.");
		}
	};
	if (!authReady) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "admin-page",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "جارٍ التحقق من جلسة الدخول..." })
	});
	if (!isFirebaseConfigured()) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "admin-page",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "إعداد Firebase غير مكتمل" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "أضف إعدادات التطبيق إلى ملف .env.local ثم أعد تشغيل الموقع." })]
	});
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "admin-page admin-login-page",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "admin-header",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "admin-brand",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, {}), " مختبر المشاريع الجامعية"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "دخول المشرف" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "هذه لوحة تجريبية محمية بحساب Firebase وصلاحية إدارة منفصلة." })
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-demo-banner",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "بيئة جامعية تجريبية." }), " الدخول بكلمة مرور فقط؛ لا يوجد تسجيل Google أو إنشاء حساب من الموقع. يمكن تغيير كلمة مرور المشرف بعد تسجيل الدخول من داخل اللوحة."]
			}),
			user?.isAnonymous && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "demo-error",
				role: "alert",
				children: "جلسة مشاركة تجريبية نشطة. سجّل الدخول بحساب المشرف للمتابعة."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "demo-error",
				role: "alert",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "admin-login-form",
				onSubmit: login,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["كلمة المرور", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "password",
					autoComplete: "current-password",
					value: password,
					onChange: (event) => setPassword(event.target.value),
					required: true
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "bank",
					disabled: loading,
					children: loading ? "جارٍ تسجيل الدخول..." : "تسجيل الدخول"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "admin-page",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "admin-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "admin-brand",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCheck, {}), " إدارة المشروع التجريبي"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "طلبات المشاركة الوهمية" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "كل عميل له سجل واحد يجمع طلب المرحلة الأولى والرقم التجريبي ومراجعتيهما." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "admin-header-actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => {
							setPasswordChangeOpen((open) => !open);
							setError("");
							setPasswordChanged(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}), " تغيير كلمة المرور"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => signOut(getFirebaseServices().auth),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {}), " تسجيل الخروج"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "admin-demo-banner",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "تنبيه: بيانات اختبار وهمية فقط." }), " لا تدخل أو تحتفظ بمعلومات أشخاص حقيقيين أو بأرقام/رموز تحقق حقيقية."]
			}),
			passwordChangeOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "admin-login-form admin-password-form",
				onSubmit: changeAdminPassword,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "تغيير كلمة مرور المشرف" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "استخدم كلمة مرور جديدة من 6 أحرف على الأقل." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["كلمة المرور الحالية", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "password",
						autoComplete: "current-password",
						value: currentPassword,
						onChange: (event) => setCurrentPassword(event.target.value),
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["كلمة المرور الجديدة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "password",
						autoComplete: "new-password",
						minLength: 6,
						value: newPassword,
						onChange: (event) => setNewPassword(event.target.value),
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["تأكيد كلمة المرور الجديدة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "password",
						autoComplete: "new-password",
						minLength: 6,
						value: confirmNewPassword,
						onChange: (event) => setConfirmNewPassword(event.target.value),
						required: true
					})] }),
					passwordChanged && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "password-success",
						role: "status",
						children: "تم تغيير كلمة المرور بنجاح."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "admin-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "bank",
							disabled: loading,
							children: loading ? "جارٍ التحديث..." : "حفظ كلمة المرور الجديدة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setPasswordChangeOpen(false),
							children: "إلغاء"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "demo-error",
				role: "alert",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "admin-stats",
				"aria-label": "ملخص الطلبات",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "كل السجلات",
						value: counts.all,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCheck, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "الطلب الأول: مراجعة",
						value: counts.requestPending,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "الطلب الأول: مقبول",
						value: counts.requestAccepted,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "الطلب الأول: مرفوض",
						value: counts.requestRejected,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "الرقم: مراجعة",
						value: counts.numberPending,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "الرقم: مقبول",
						value: counts.numberAccepted,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "الرقم: مرفوض",
						value: counts.numberRejected,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "admin-filters",
				"aria-label": "تصفية الطلبات",
				children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: filter === item.key ? "active" : "",
					"aria-pressed": filter === item.key,
					onClick: () => setFilter(item.key),
					children: item.label
				}, item.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "admin-list",
				"aria-live": "polite",
				children: filteredSubmissions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "admin-empty",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCheck, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "لا توجد طلبات هنا" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ستظهر الطلبات التجريبية بعد إرسالها من الصفحة الرئيسية." })
					]
				}) : filteredSubmissions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "admin-submission admin-submission-clickable",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "admin-card-open",
						"aria-label": `فتح تفاصيل الطلب التجريبي ${item.id.slice(0, 6)}`,
						onClick: () => setSelectedSubmissionId(item.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubmissionSummary, { item }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "admin-card-hint",
							children: "اضغط على البطاقة لعرض كل التفاصيل"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubmissionActions, {
						item,
						onRequestStatus: (status) => updateRequestStatus(item.id, status),
						onNumberStatus: (status) => updateNumberStatus(item.id, status)
					})]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(selectedSubmission),
				onOpenChange: (open) => {
					if (!open) setSelectedSubmissionId(null);
				},
				children: selectedSubmission && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "admin-details-dialog",
					dir: "rtl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "تفاصيل سجل العميل التجريبي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "سجل واحد للمرحلتين؛ أي تغيير يظهر للعميل صاحب هذا السجل فقط." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "admin-modal-order",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "رقم السجل" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								dir: "ltr",
								children: ["#", selectedSubmission.id]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "admin-details admin-details-expanded",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "معرّف العميل الوهمي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: selectedSubmission.participantNumber })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "المرجع التجريبي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: selectedSubmission.couponReference })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "الرقم التجريبي المُرسل" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "admin-coupon",
									dir: "ltr",
									children: selectedSubmission.couponCode || "لم يُرسل بعد"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "حالة الطلب الأول" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `admin-status ${selectedSubmission.status}`,
									children: requestStatusLabel(selectedSubmission.status)
								}) })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "حالة مراجعة الرقم" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `admin-status ${numberStatusClass(selectedSubmission.couponStatus)}`,
									children: numberStatusLabel(selectedSubmission.couponStatus)
								}) })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "وقت إنشاء الطلب" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: new Date(selectedSubmission.createdAt).toLocaleString("ar-EG") })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "admin-modal-owner",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "معرّف جلسة العميل" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										dir: "ltr",
										children: selectedSubmission.ownerUid
									})]
								})
							]
						}),
						selectedSubmission.status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "admin-review-block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "مراجعة الطلب الأول" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "admin-actions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "bank",
									onClick: () => updateRequestStatus(selectedSubmission.id, "accepted"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " قبول الطلب"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => updateRequestStatus(selectedSubmission.id, "rejected"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " رفض الطلب"]
								})]
							})]
						}),
						selectedSubmission.status === "accepted" && selectedSubmission.couponStatus === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "admin-review-block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "مراجعة الرقم التجريبي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "admin-actions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "bank",
									onClick: () => updateNumberStatus(selectedSubmission.id, "accepted"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " قبول الرقم"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => updateNumberStatus(selectedSubmission.id, "rejected"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " رفض الرقم"]
								})]
							})]
						})
					]
				})
			})
		]
	});
}
function matchesFilter(item, filter) {
	switch (filter) {
		case "request_pending": return item.status === "pending";
		case "request_accepted": return item.status === "accepted";
		case "request_rejected": return item.status === "rejected";
		case "number_pending": return item.couponStatus === "pending";
		case "number_accepted": return item.couponStatus === "accepted";
		case "number_rejected": return item.couponStatus === "rejected";
		default: return true;
	}
}
function requestStatusLabel(status) {
	return status === "pending" ? "قيد المراجعة" : status === "accepted" ? "مقبول" : "مرفوض";
}
function numberStatusLabel(status) {
	switch (status ?? "not_submitted") {
		case "pending": return "قيد المراجعة";
		case "accepted": return "مقبول";
		case "rejected": return "مرفوض — يمكن إعادة الإرسال";
		default: return "لم يُرسل بعد";
	}
}
function numberStatusClass(status) {
	return status === "accepted" ? "accepted" : status === "rejected" ? "rejected" : "";
}
function SubmissionSummary({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "admin-submission-top",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "admin-order",
				children: ["طلب تجريبي #", item.id.slice(0, 6).toUpperCase()]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `admin-status ${item.status}`,
				children: requestStatusLabel(item.status)
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", { children: new Date(item.createdAt).toLocaleString("ar-EG") })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "admin-card-statuses",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["المرحلة الثانية: ", numberStatusLabel(item.couponStatus)] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "admin-details",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "معرّف العميل الوهمي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: item.participantNumber })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "المرجع التجريبي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: item.couponReference })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "الرقم التجريبي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "admin-coupon",
					dir: "ltr",
					children: item.couponCode || "لم يُرسل بعد"
				})] })
			]
		})
	] });
}
function SubmissionActions({ item, onRequestStatus, onNumberStatus }) {
	if (item.status === "pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "admin-actions",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "bank",
			onClick: () => onRequestStatus("accepted"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " قبول الطلب"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			onClick: () => onRequestStatus("rejected"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " رفض الطلب"]
		})]
	});
	if (item.status === "accepted" && item.couponStatus === "pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "admin-actions",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "bank",
			onClick: () => onNumberStatus("accepted"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " قبول الرقم"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			onClick: () => onNumberStatus("rejected"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " رفض الرقم"]
		})]
	});
	return null;
}
function Stat({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "admin-stat",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: value }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: label })] })]
	});
}
//#endregion
export { AdminPage as component };
